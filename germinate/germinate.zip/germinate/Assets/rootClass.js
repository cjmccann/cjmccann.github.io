﻿#pragma strict
var full : boolean;
var rootLeft : boolean;
var rootRight : boolean;
var rootCenter : boolean;

function Start () {
	full = false;
	rootLeft = false;
	rootRight = false;
	rootCenter = false;
}

function Update () {

}