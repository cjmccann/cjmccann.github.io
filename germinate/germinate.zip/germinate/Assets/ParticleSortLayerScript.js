﻿#pragma strict

function Start () {
	particleSystem.renderer.sortingLayerName = "Background";
}

function Update () {

}